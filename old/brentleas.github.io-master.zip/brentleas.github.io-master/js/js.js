$(".button-collapse").sideNav();

 $(document).ready(function(){
    $('.collapsible').collapsible();
  });